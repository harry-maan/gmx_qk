/*! \defgroup module_example "Example module (example)"
 * \ingroup group_utilitymodules
 * \brief
 * Brief description for the module.
 *
 * Detailed description of the module.  Can link to a separate Doxygen page for
 * overview, and/or describe the most important headers and/or classes in the
 * module as part of this documentation.
 *
 * For modules not exposed publicly, \\libinternal can be added at the
 * beginning (before \\defgroup).
 *
 * \author Author Name <author.name@email.com>
 */

// In other code, use \addtogroup module_example and \ingroup module_example to
// add content (classes, functions, etc.) onto the module page.
