=============================
Automation and Infrastructure
=============================

Through the 2020 release, automated testing and documentation builds are
performed by a Jenkins installation. With the resolution of :issue:`3272`,
|Gromacs| is transitioning to GitLab and GitLab Runner.

..  toctree::
    :maxdepth: 2

    jenkins
    gitlab
    containers

