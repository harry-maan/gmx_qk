.. This file is a placeholder that is used in case RELENG_PATH does not
   identify the location of the releng repository.

.. _jenkins-ui:

jenkins ui (missing)
===========================

This documentation was built without releng documentation.
If you want to see this documentation, set ``RELENG_PATH`` CMake variable to
point to the root of a checkout from the releng repository.
